# StudyBuddy AI Doubt Solver — v2
**Created by Prince Kumar**

## Included in this build
- Android packaging configuration using Capacitor (Android project is generated during setup).
- Student registration and sign-in with hashed passwords and JWT sessions.
- Per-account doubt history, with delete controls.
- Voice input (browser speech recognition) and text-to-speech answer playback where supported.
- Admin dashboard: user count, doubt count, and Free/Premium account assignment.
- Plan comparison screen. Premium is marked "Coming soon"; no payments are collected or payment processor configured.
- AI question solving for typed text and uploaded question images.

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `OPENAI_API_KEY` and a long random `JWT_SECRET`.
5. Set `ADMIN_EMAIL` to the email address that should receive admin role at registration.
6. Run `npm start`, then open `http://localhost:3000`.

The first registration using the configured `ADMIN_EMAIL` gets the admin role. Keep `.env` and `studybuddy.db` private. Use HTTPS in production.

## Build Android app
1. Install Android Studio and its Android SDK.
2. Start the web server and test the web app.
3. For a production Android package, host the web app over HTTPS and configure Capacitor's server URL or bundle a built frontend according to your deployment setup.
4. Run `npx cap add android` (first time), then `npx cap sync android`, then `npx cap open android`.
5. Build/sign the APK or AAB in Android Studio.

This starter includes Capacitor configuration but does not include a prebuilt APK or Google Play release.

## Telegram
Telegram was not among the selected numbered items. The project currently includes web + Android packaging only.

## Important
- The app needs an OpenAI API key and API usage may incur charges. Get permission from a parent/guardian before enabling paid API access.
- No subscription payment gateway is connected. Do not advertise or collect Premium payments until pricing, terms, refunds, privacy, and a payment provider are configured by an adult account owner.
- Add production protections before public launch: HTTPS, rate limiting, email verification, password reset, backups, privacy policy, abuse monitoring, and secure secret management.
- Voice input depends on browser/device support and may require internet access.
